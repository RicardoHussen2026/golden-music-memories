import {Composition} from 'remotion';
import {GoldenMusicMemories, MemoryCard} from './Composition';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition id="GoldenMusicMemories" component={GoldenMusicMemories} durationInFrames={900} fps={30} width={1080} height={1920} />
      <Composition id="TextoEditorial" component={MemoryCard} durationInFrames={90} fps={30} width={1080} height={1920} defaultProps={{label: 'DÊ PLAY NA MEMÓRIA', text: 'Você lembra\ndesse começo?', detail: '', duration: 3}} />
    </>
  );
};
