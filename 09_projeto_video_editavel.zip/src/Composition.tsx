import React from 'react';
import {AbsoluteFill, CanvasImage, Interactive, InteractivitySchema, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

const gold = '#edc283';
const paper = '#f5eee2';

type CardProps = {
  readonly label: string;
  readonly text: string;
  readonly detail: string;
  readonly duration: number;
};

const MemoryCardInner: React.FC<CardProps> = ({label, text, detail, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <Interactive.Div name="Texto editorial" style={{position: 'absolute', left: 90, top: 730, width: 800, fontFamily: 'Arial, sans-serif', opacity: interpolate(frame, [0, 0.2 * fps, (duration - 0.2) * fps, duration * fps], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), translate: interpolate(frame, [0, 0.3 * fps], ['0px 12px', '0px 0px'], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}>
    <div style={{fontSize: 25, fontWeight: 700, letterSpacing: 5, color: gold, marginBottom: 24}}>{label}</div>
    <div style={{fontSize: 62, fontWeight: 700, lineHeight: 1.12, letterSpacing: -1.3, color: paper, whiteSpace: 'pre-line'}}>{text}</div>
    {detail ? <div style={{fontSize: 44, lineHeight: 1.23, color: paper, marginTop: 22, whiteSpace: 'pre-line'}}>{detail}</div> : null}
  </Interactive.Div>;
};

const cardSchema = {
  label: {type: 'text-content', default: 'MEMÓRIA MUSICAL', description: 'Chamada pequena'},
  text: {type: 'text-content', default: '', description: 'Texto principal'},
  detail: {type: 'text-content', default: '', description: 'Explicação'},
  duration: {type: 'number', default: 3, description: 'Duração em segundos', hiddenFromList: true},
} as const satisfies InteractivitySchema;

export const MemoryCard = Interactive.withSchema({Component: MemoryCardInner, componentName: '<MemoryCard>', schema: cardSchema, wrapInSequence: true, layout: 'absolute-fill'});

export const GoldenMusicMemories: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  return <AbsoluteFill style={{background: '#031419', color: paper, fontFamily: 'Arial, sans-serif', overflow: 'hidden'}}>
    <CanvasImage name="Cassete original" src={staticFile('cassete-original.png')} premountFor={fps} style={{position: 'absolute', width: '100%', height: '100%', objectFit: 'cover', scale: interpolate(frame, [0, durationInFrames - 1], [1, 1.06], {extrapolateRight: 'clamp'})}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,12,16,0.25) 0%, rgba(0,12,16,0.25) 42%, rgba(0,12,16,0) 65%, rgba(0,12,16,0.12) 100%)'}} />
    <Interactive.Div name="Marca" style={{position: 'absolute', left: 90, top: 220, width: 810, display: 'flex', gap: 18, alignItems: 'center'}}>
      <div style={{width: 54, height: 54, border: `2px solid ${gold}`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><div style={{width: 16, height: 16, border: `2px solid ${gold}`, borderRadius: '50%'}} /></div>
      <div style={{fontSize: 29, fontWeight: 700, letterSpacing: 2.1, color: gold}}>GOLDEN MUSIC MEMORIES</div>
    </Interactive.Div>
    <Interactive.Div name="Identificação da música" style={{position: 'absolute', top: 380, left: 90, width: 810}}>
      <div style={{height: 4, width: 100, background: gold, marginBottom: 34}} />
      <div style={{fontSize: 100, lineHeight: 1, fontWeight: 800, letterSpacing: -5, color: paper}}>TAKE ON ME</div>
      <div style={{marginTop: 28, display: 'flex', alignItems: 'center', gap: 26}}>
        <span style={{fontSize: 58, fontWeight: 600, letterSpacing: -1}}>a-ha</span>
        <span style={{height: 42, width: 2, background: '#edc28388'}} />
        <span style={{fontSize: 42, fontWeight: 400, color: gold, letterSpacing: 3}}>1985</span>
      </div>
    </Interactive.Div>
    <MemoryCard name="Abertura" from={0} durationInFrames={3 * fps} premountFor={fps} label="DÊ PLAY NA MEMÓRIA" text={'Você lembra\ndesse começo?'} detail="" duration={3} />
    <MemoryCard name="Curiosidade do clipe" from={3 * fps} durationInFrames={7 * fps} premountFor={fps} label="POR TRÁS DO CLÁSSICO" text={'O clipe misturou\ncenas reais\ne desenhos.'} detail="" duration={7} />
    <MemoryCard name="O que é rotoscopia" from={10 * fps} durationInFrames={10 * fps} premountFor={fps} label="A TÉCNICA" text="Rotoscopia." detail={'Imagens filmadas, redesenhadas\nquadro a quadro.'} duration={10} />
    <MemoryCard name="Conversa com o público" from={20 * fps} durationInFrames={7 * fps} premountFor={fps} label="A SUA HISTÓRIA" text={'Qual lembrança\nessa música traz?'} detail="" duration={7} />
    <MemoryCard name="Encerramento" from={27 * fps} durationInFrames={3 * fps} premountFor={fps} label="AS DÉCADAS PASSAM. O SOM FICA." text={'Anos 70 • 80 • 90\ne 2000'} detail="Golden Music Memories" duration={3} />
    <Sequence name="Linha do tempo" from={0} durationInFrames={30 * fps} premountFor={fps}>
      <div style={{position: 'absolute', left: 90, top: 1390, width: 800, height: 3, background: '#edc28344'}}>
        <div style={{height: 3, width: `${interpolate(frame, [0, durationInFrames - 1], [0, 100])}%`, background: gold}} />
      </div>
    </Sequence>
  </AbsoluteFill>;
};
